package com.example.cse.myapplication;

import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class SetAlarm extends AppCompatActivity {

    public Button btnBack;
    public Button btnMake;
    public Button btnSet;
    public Switch reBtn;

    final Calendar c = Calendar.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_alarm);

        btnBack=(Button)findViewById(R.id.backFromSetAlarm);
        btnMake=(Button)findViewById(R.id.doMake);
        btnSet=(Button)findViewById(R.id.doSet);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnMake.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //알람만들어져야하는데으어아으어아아아아아
            }
        });

        btnSet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int myHour = c.get(Calendar.HOUR_OF_DAY);
                int myMinute = c.get(Calendar.MINUTE);
                Toast.makeText(SetAlarm.this,
                        "- onCreateDialog(ID_TIMEPICKER) -",
                        Toast.LENGTH_LONG)
                        .show();
                Dialog dlgTime = new TimePickerDialog(SetAlarm.this, myTimeSetListener, myHour,
                        myMinute, false);
                dlgTime.show();
            }
        });
    }

    private TimePickerDialog.OnTimeSetListener myTimeSetListener
            = new TimePickerDialog.OnTimeSetListener() {

        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            String time = "Hour: " + String.valueOf(hourOfDay) + "\n"
                    + "Minute: " + String.valueOf(minute);
            Toast.makeText(SetAlarm.this, time, Toast.LENGTH_LONG).show();
        }
    };
}
