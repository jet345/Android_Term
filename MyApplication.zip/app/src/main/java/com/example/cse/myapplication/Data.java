package com.example.cse.myapplication;

/**
 * Created by a_l18 on 2016-05-24.
 */
import java.io.Serializable;

public class Data implements Serializable {

    public String name;
    public String corp;

    public Data() {}

    public Data(String name, String corp) {
        this.name = name;
        this.corp = corp;
    }
}