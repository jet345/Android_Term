package com.example.cse.myapplication;

import android.app.ActionBar;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SearchMain extends AppCompatActivity {

    public Button nameSelect;
    public Button shapeSelect;
    public Button backSelect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_main);

        nameSelect=(Button) findViewById(R. id. selectName);
        shapeSelect=(Button) findViewById(R. id. selectShape);
        backSelect=(Button) findViewById(R. id. selectBack);

        nameSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goName=new Intent(SearchMain.this, SearchName.class);
                startActivity(goName);
            }
        });

        shapeSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goShape = new Intent(SearchMain.this, SearchShape.class);
                startActivity(goShape);
            }
        });

        backSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
