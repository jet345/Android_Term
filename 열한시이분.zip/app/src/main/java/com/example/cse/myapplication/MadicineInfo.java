package com.example.cse.myapplication;

import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class MadicineInfo extends AppCompatActivity {

    public Button backButton;
    private TextView putText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_madicine_info);

        putText=(TextView)findViewById(R.id.textSee);
        backButton=(Button)findViewById(R. id. backFromInfo);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Intent searching=getIntent();
        String name=searching.getStringExtra("NameIn");
        String corp=searching.getStringExtra("CorpIn");


    }


    public static final String ROOT_DIR = "C:/Users/cse/Downloads/";
    private static final String DATABASE_NAME = "drug.db";
    public static final String TABLE_NAME = "medicine";
    private static final String COLUMN_KEY_ID = "_id";
    private static final String COLUMN_NAME = "name";

    public static void initialize(Context ctx) {
        // check
        File folder = new File(ROOT_DIR + "databases");
        folder.mkdirs();
        File outfile = new File(ROOT_DIR + "databases/" + DATABASE_NAME);
        if (outfile.length() <= 0) {
            AssetManager assetManager = ctx.getResources().getAssets();
            try {
                InputStream is = assetManager.open(DATABASE_NAME, AssetManager.ACCESS_BUFFER);
                long filesize = is.available();
                byte [] tempdata = new byte[(int)filesize];
                is.read(tempdata);
                is.close();

                outfile.createNewFile();
                FileOutputStream fo = new FileOutputStream(outfile);
                fo.write(tempdata);
                fo.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public String[] search(String name, String corp) {
        String[] result;

    }
}
