package com.example.cse.myapplication;

import android.app.ActionBar;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SearchShape extends AppCompatActivity {

    public Button shapeSearch;
    public Button selectBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_shape);

        shapeSearch=(Button)findViewById(R. id. doShapeSearch);
        selectBack=(Button)findViewById(R. id. backFromSearchShape);

        shapeSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent doSearch = new Intent(SearchShape.this, MadicineInfo.class);
                startActivity(doSearch);
            }
        });

        selectBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
