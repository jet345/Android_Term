package com.example.cse.myapplication;

import android.app.ActionBar;
import android.content.Intent;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SearchName extends AppCompatActivity {

    public EditText inputName;
    public EditText inputCorp;
    public Button goSearch;
    public Button backSelect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_name);

        inputName=(EditText)findViewById(R. id. drugName);
        inputCorp=(EditText)findViewById(R. id. drugCorp);
        goSearch=(Button)findViewById(R. id. doSearch);
        backSelect=(Button)findViewById(R. id. backFromSearchName);

        goSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(inputName.getText().toString()==null  && inputName.getText().toString()==null) {
                    Toast.makeText(getApplicationContext(), "이름과 제조사명 중 하나는 입력해주세요 T.T", Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent doSearch = new Intent(SearchName.this, MadicineInfo.class);
                    doSearch.putExtra("NameIn", inputName.getText().toString());
                    doSearch.putExtra("CorpIn", inputName.getText().toString());
                    startActivity(doSearch);
                }
            }
        });

        backSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
