package com.example.cse.myapplication.SearchBox;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.cse.myapplication.R;

public class MedicineInfo extends AppCompatActivity {

    TextView txtMsg;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medicine_info);

        //putText=(TextView)findViewById(R.id.textSee);

        txtMsg = (TextView)findViewById(R.id.txtMsg);


        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        String prodKName = bundle.getString("data0");
        String drugCode = bundle.getString("data1");
        String drugName = bundle.getString("data2");
        String distrName = bundle.getString("data3");

        Cursor cursor = DatabaseHelper.queryDetailsTable(drugCode);

        HandleCursorData (cursor );

    }

    public void HandleCursorData ( Cursor outCursor ) {

        int recordCount = outCursor.getCount();
        // println("cursor count : " + recordCount + "\n");

        // get column index
        int drugCodeCol = outCursor.getColumnIndex("DRUGCODE");
        int classCodeCol = outCursor.getColumnIndex("CLASSCODE");
        int classNameCol = outCursor.getColumnIndex("CLASSNAME");
        int detailsCol = outCursor.getColumnIndex("DETAILS");

        for (int i = 0; i < recordCount; i++) {
            outCursor.moveToNext();
            String drugCode = outCursor.getString(drugCodeCol);
            String classCode = outCursor.getString(classCodeCol);
            String className = outCursor.getString(classNameCol);
            String details = outCursor.getString(detailsCol);

            txtMsg.append("\n");
            txtMsg.append("[" + className + "]\n");
            txtMsg.append("\n");
            txtMsg.append(details + "\n\n");
            txtMsg.append("--------------------------------------------------------");
            txtMsg.append("\n");

        }

        outCursor.close();

    }
}
