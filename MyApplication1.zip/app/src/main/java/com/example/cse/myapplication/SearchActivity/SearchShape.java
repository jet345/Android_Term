package com.example.cse.myapplication.SearchActivity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.cse.myapplication.R;
import com.example.cse.myapplication.SearchBox.DataListView;
import com.example.cse.myapplication.SearchBox.DatabaseHelper;
import com.example.cse.myapplication.SearchBox.IconTextItem;
import com.example.cse.myapplication.SearchBox.IconTextListAdapter;
import com.example.cse.myapplication.SearchBox.MedicineInfo;
import com.example.cse.myapplication.SearchBox.OnDataSelectionListener;

public class SearchShape extends AppCompatActivity {

    public Button shapeSearch;

    CheckBox checkCircle, checkOgak, checkRec, checkTri, checkT, checkWhite, checkRed,
    checkYello, checkGreen, checkBlue, checkEtcColor, checkForm1, checkForm2, checkEtcForm;

    String checked_S="", checked_C="", checked_F="";
    static int S_count=0, C_count=0, F_count=0;

    String strSearchQuery_S;
    String strSearchQuery_C;
    String strSearchQuery_F;

    DataListView listView;
    IconTextListAdapter adapter;
    InputMethodManager imm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_shape);

        checkCircle=(CheckBox)findViewById(R.id.checkCircle);
        checkOgak=(CheckBox)findViewById(R.id.checkOgak);
        checkRec=(CheckBox)findViewById(R.id.checkRec);
        checkTri=(CheckBox)findViewById(R.id.checkTri);
        checkT=(CheckBox)findViewById(R.id.checkT);
        checkWhite=(CheckBox)findViewById(R.id.check_white);
        checkRed=(CheckBox)findViewById(R.id.check_red);
        checkYello=(CheckBox)findViewById(R.id.check_yellow);
        checkGreen=(CheckBox)findViewById(R.id.check_green);
        checkBlue=(CheckBox)findViewById(R.id.check_blue);
        checkEtcColor=(CheckBox)findViewById(R.id.check_etc_color);
        checkForm1=(CheckBox)findViewById(R.id.checkForm1);
        checkForm2=(CheckBox)findViewById(R.id.checkForm2);

        imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
        adapter = new IconTextListAdapter(this);// adapter
        listView = new DataListView(this);// ListView

        LinearLayout linLayout = (LinearLayout)findViewById(R.id._linLayoutDrugList );
        linLayout.addView(listView);
        // open database
        DatabaseHelper.mContext = getApplicationContext();
        DatabaseHelper.openDatabase(DatabaseHelper.drugDatabaseFile);

        shapeSearch=(Button)findViewById(R. id. doShapeSearch);
        shapeSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                check();
                if (S_count>1 && C_count>1 && F_count>1)
                {
                    Toast.makeText(SearchShape.this, "하나씩만 체크해 주세요!\n" +
                            "한 항목에서 하나씩만 체크할 수 있습니다.", Toast.LENGTH_LONG).show();
                }
               /*else if (S_count==0 && C_count==0 && F_count==0)
                {
                    Toast.makeText(SearchShape.this, "적어도 한 항목은 체크되어야 검색이 가능합니다.", Toast.LENGTH_LONG).show();
                }*/
                else {
                    strSearchQuery_S=checked_S.concat("%");
                    strSearchQuery_C=checked_C.concat("%");
                    strSearchQuery_F=checked_F.concat("%");

                    Cursor cursor = DatabaseHelper.queryMasterTable(strSearchQuery_F, strSearchQuery_C, strSearchQuery_S);
                    AddCursorData(cursor);// bind Adapter
                    listView.setAdapter(adapter);
                }
            }
        });

        listView.setOnDataSelectionListener( new OnDataSelectionListener() {

            public void onDataSelected(AdapterView parent, View v, int position, long id) {
                // make intent
                IconTextItem selectItem = (IconTextItem)adapter.getItem(position);

                //String title = selectItem.getData(0);
                Bundle bundle = new Bundle();
                bundle.putString("data0", selectItem.getData(0));
                bundle.putString("data1", selectItem.getData(1));
                bundle.putString("data2", selectItem.getData(2));
                bundle.putString("data3", selectItem.getData(3));

                Intent intent = new Intent( getApplicationContext(), MedicineInfo.class );
                intent.putExtras(bundle);
                startActivity ( intent );
            }
        });

        checkDangerousPermissions();
    }

    void check() {
        boolean checkShape[]={checkCircle.isChecked(), checkOgak.isChecked(), checkRec.isChecked(),
                checkTri.isChecked(), checkT.isChecked()};
        boolean checkColor[]={checkWhite.isChecked(), checkRed.isChecked(),
                checkYello.isChecked(), checkGreen.isChecked(), checkBlue.isChecked(), checkEtcColor.isChecked()};
        boolean checkForm[]={ checkForm1.isChecked(), checkForm2.isChecked()};

        String stringShape[]={"원형", "오각형", "사각형", "삼각형", "타원형"};
        String stringColor[]={"하양", "빨강", "노랑", "초록", "파랑", "기타"};
        String stringForm[]={"정제류", "경질캡슐"};


        for (int i=0; i<checkShape.length; i++) {
            if (checkShape[i]) checked_S=stringShape[i]; //S_count++;
        }

        for (int i=0; i<checkColor.length; i++) {
            if (checkColor[i]) checked_C=stringColor[i]; //C_count++;
        }

        for (int i=0; i<checkForm.length; i++) {
            if (checkForm[i]) checked_F=stringForm[i]; //F_count++;
        }
    }

    private void checkDangerousPermissions() {
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
        int permissionCheck2 = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "권한 있음", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "권한 없음", Toast.LENGTH_LONG).show();

            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {
                Toast.makeText(this, "권한 설명 필요함.", Toast.LENGTH_LONG).show();
            } else {
                String[] permissions = {
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                };

                ActivityCompat.requestPermissions(this, permissions, 1);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 1) {
            for (int i = 0; i < permissions.length; i++) {
                if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, permissions[i] + " 권한이 승인됨.", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, permissions[i] + " 권한이 승인되지 않음.", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    protected void onDestroy() {
        super.onDestroy();

        DatabaseHelper.closeDatabase();
    }

    public void AddCursorData ( Cursor outCursor ) {

        int recordCount = outCursor.getCount();
        //println("cursor count : " + recordCount + "\n");

        adapter.clear();

        // get column index
        int drugCodeCol = outCursor.getColumnIndex("DRUGCODE");
        int drugNameCol = outCursor.getColumnIndex("DRUGNAME");
        int prodKNameCol = outCursor.getColumnIndex("PRODKRNM");
        int distrNameCol = outCursor.getColumnIndex("DISTRNAME");

        // get reaources
        Resources res = getResources();

        for (int i = 0; i < recordCount; i++) {
            outCursor.moveToNext();
            String drugCode = outCursor.getString(drugCodeCol);
            String drugName = outCursor.getString(drugNameCol);
            String prodKName = outCursor.getString(prodKNameCol);
            String distrName = outCursor.getString(distrNameCol);

            adapter.addItem( new IconTextItem(res.getDrawable(R.drawable.capsule1),prodKName,drugCode ,drugName,distrName));
        }

        outCursor.close();
    }
}
