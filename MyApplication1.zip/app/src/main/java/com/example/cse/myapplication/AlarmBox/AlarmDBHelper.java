package com.example.cse.myapplication.AlarmBox;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by a_l18 on 2016-06-06.
 */

public class AlarmDBHelper extends SQLiteOpenHelper{
    static SQLiteDatabase database=null;
    static AlarmDBHelper instance=null;
    private static final String DATABASE_NAME = "list.db";
    private static final int DATABASE_VERSION =1;
    public static SQLiteDatabase mDB;

    public AlarmDBHelper (Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    public static SQLiteDatabase getDatabase() {
        if (null == database) {
            database=instance.getWritableDatabase();
        }
        return database;
    }


    public static int deleteEntry(int id){
        return getDatabase().delete("contact", "_id" + "=" + id, null);
    }


        @Override
        public void onCreate(SQLiteDatabase db) {

            //테이블 생성
            db.execSQL("CREATE TABLE contact (_id INTEGER PRIMARY KEY AUTOINCREMENT, time TEXT, repeat TEXT, tag TEXT);");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXITS contact");
            onCreate(db);
        }

}