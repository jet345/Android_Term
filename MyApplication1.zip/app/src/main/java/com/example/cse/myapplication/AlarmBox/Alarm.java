package com.example.cse.myapplication.AlarmBox;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CursorAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.example.cse.myapplication.R;


public class Alarm extends AppCompatActivity {
    public ImageButton plus;
    public ListView list;

    AlarmDBHelper helper;
    SQLiteDatabase db;
    CursorAdapter adapter;

    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm);

        //adapter.changeCursor(cursor);

        plus = (ImageButton) findViewById(R.id.plusAlarm);
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Alarm.this, AlarmSet.class);
                startActivity(intent);
            }
        });

        list = (ListView) findViewById(R.id.alarmList);

        helper = new AlarmDBHelper(this);
        db = helper.getWritableDatabase();
        cursorChg();
        list.setOnItemClickListener(listener);

    }

    @Override
    protected void onStart() {
        super.onStart();
        cursorChg();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        cursorChg();
    }

    void cursorChg() {
        cursor = db.rawQuery("select * from contact", null);
        adapter = new CursorAdapter(this, cursor) {

            @Override
            public View newView(Context context, Cursor cursor, ViewGroup parent) {
                LayoutInflater inflater = LayoutInflater.from(context);
                View view = inflater.inflate(R.layout.listalarm, parent, false);
                return view;
            }

            @Override
            public void bindView(View view, Context context, Cursor cursor) {
                TextView text1 = (TextView) view.findViewById(R.id.tvTime);
                TextView text2 = (TextView) view.findViewById(R.id.tvRepeat);
                TextView text3 = (TextView) view.findViewById(R.id.tvTag);
                text1.setText(cursor.getString(1));
                text2.setText(cursor.getString(2));
                text3.setText(cursor.getString(3));
                return;
            }
        };
        list.setAdapter(adapter);
    }
    AdapterView.OnItemClickListener listener= new AdapterView.OnItemClickListener() {
       //http://kitesoft.tistory.com/67
        //ListView의 아이템 중 하나가 클릭될 때 호출되는 메소드
        //첫번째 파라미터 : 클릭된 아이템을 보여주고 있는 AdapterView 객체(여기서는 ListView객체)
        //두번째 파라미터 : 클릭된 아이템 뷰
        //세번째 파라미터 : 클릭된 아이템의 위치(ListView이 첫번째 아이템(가장위쪽)부터 차례대로 0,1,2,3.....)
        //네번재 파리미터 : 클릭된 아이템의 아이디(특별한 설정이 없다면 세번째 파라이터인 position과 같은 값)
        @Override
        public void onItemClick(final AdapterView<?> parent, final View view, final int position, final long id) {
            final AlertDialog.Builder alert = new AlertDialog.Builder(Alarm.this);
            alert.setTitle("알람 삭제");
            alert.setMessage("선택한 알람을 삭제하시겠습니까?");
            alert.setCancelable(false);
            alert.setPositiveButton("예", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    db.execSQL("delete from contact where _id="+position+";");
                    //포지션으로 삭ㅈㅔ하면 나중에 포지션 바뀌었을때 다시 삭제 안됨....
                    //삭제할때마다 카운트해서 포지션에 더하면 되지 않을까.. 안될수도있음
                    Cursor cursor1=db.rawQuery("select * from contact", null);
                    adapter.changeCursor(cursor1);
                    list.setAdapter(adapter);
                }

            });

            alert.setNegativeButton("아니오", new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int which) {
                }
            });

            alert.show();
        }
    };
        //http://blog.naver.com/PostView.nhn?blogId=javaking75&logNo=140177619818


}

