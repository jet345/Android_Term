package com.example.cse.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import com.example.cse.myapplication.AlarmBox.Alarm;

public class MainActivity extends AppCompatActivity {

    public ImageButton searchDrug;
    public ImageButton historyDrug;
    public ImageButton plusDrug;
    public ImageButton alarmDrug;
    public EditText quickSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchDrug = (ImageButton) findViewById(R.id.drugSearch);
        historyDrug = (ImageButton) findViewById(R.id.drugHistroy);
        plusDrug = (ImageButton) findViewById(R.id.drugPlus);
        alarmDrug = (ImageButton) findViewById(R.id.drugAlarm);
        quickSearch = (EditText) findViewById(R.id.QuickSearch);

        searchDrug.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goSearch = new Intent(MainActivity.this, SearchMain.class);
                startActivity(goSearch);
            }
        });

        historyDrug.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goHistory = new Intent(MainActivity.this, History.class);
                startActivity(goHistory);
            }
        });

        plusDrug.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goPlus = new Intent(MainActivity.this, PharmacySearch.class);
                startActivity(goPlus);
            }
        });

        alarmDrug.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goAlarm = new Intent(MainActivity.this, Alarm.class);
                startActivity(goAlarm);
            }
        });

    }
}
