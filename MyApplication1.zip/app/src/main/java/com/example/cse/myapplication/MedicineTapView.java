package com.example.cse.myapplication;

import android.app.Activity;
import android.app.TabActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;
import android.widget.TextView;

public class MedicineTapView extends TabActivity {


    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medicine_tap_view);

/*
        TabHost tabHost=(TabHost) findViewById(android.R.id.tabhost);
        tabHost.setup();

        TabSpec spec1 = tabHost.newTabSpec("Tab1").setContent(R.id.tab1).setIndicator(getString(R.string.tab1));
        tabHost.addTab(spec1);
        TabSpec spec2 = tabHost.newTabSpec("Tab2").setContent(R.id.tab2).setIndicator(getString(R.string.tab2));
        tabHost.addTab(spec2);
        TabSpec spec3 = tabHost.newTabSpec("Tab3").setContent(R.id.tab3).setIndicator(getString(R.string.tab3));
        tabHost.addTab(spec3);
        TabSpec spec4 = tabHost.newTabSpec("Tab4").setContent(R.id.tab4).setIndicator(getString(R.string.tab4));
        tabHost.addTab(spec4);
        TabSpec spec5 = tabHost.newTabSpec("Tab5").setContent(R.id.tab5).setIndicator(getString(R.string.tab5));
        tabHost.addTab(spec5);

        tabHost.getTabContentView().getChildAt(0).getLayoutParams().height=80;
        tabHost.getTabContentView().getChildAt(1).getLayoutParams().height=80;
        tabHost.getTabContentView().getChildAt(2).getLayoutParams().height=80;
        tabHost.getTabContentView().getChildAt(3).getLayoutParams().height=80;
        tabHost.getTabContentView().getChildAt(4).getLayoutParams().height=80;

        RelativeLayout.LayoutParams tv=new RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);

        RelativeLayout rl1=(RelativeLayout) tabHost.getTabWidget().getChildAt(0);
        rl1.setGravity(Gravity.CENTER_VERTICAL);
        TextView tv1=(TextView) rl1.getChildAt(1);
        tv1.setLayoutParams(tv);
        tv1.setTextAppearance(this, android.R.style.TextAppearance_Medium);
        tv1.setPadding(10, 0, 10, 0);
        tv1.setGravity(Gravity.CENTER);

        RelativeLayout rl2=(RelativeLayout) tabHost.getTabWidget().getChildAt(1);
        rl1.setGravity(Gravity.CENTER_VERTICAL);
        TextView tv2=(TextView) rl1.getChildAt(1);
        tv2.setLayoutParams(tv);
        tv2.setTextAppearance(this, android.R.style.TextAppearance_Medium);
        tv2.setPadding(10, 0, 10, 0);
        tv2.setGravity(Gravity.CENTER);

        RelativeLayout rl3=(RelativeLayout) tabHost.getTabWidget().getChildAt(2);
        rl1.setGravity(Gravity.CENTER_VERTICAL);
        TextView tv3=(TextView) rl1.getChildAt(1);
        tv3.setLayoutParams(tv);
        tv3.setTextAppearance(this, android.R.style.TextAppearance_Medium);
        tv3.setPadding(10, 0, 10, 0);
        tv3.setGravity(Gravity.CENTER);

        RelativeLayout rl4=(RelativeLayout) tabHost.getTabWidget().getChildAt(3);
        rl1.setGravity(Gravity.CENTER_VERTICAL);
        TextView tv4=(TextView) rl1.getChildAt(1);
        tv4.setLayoutParams(tv);
        tv4.setTextAppearance(this, android.R.style.TextAppearance_Medium);
        tv4.setPadding(10, 0, 10, 0);
        tv4.setGravity(Gravity.CENTER);

        RelativeLayout rl5=(RelativeLayout) tabHost.getTabWidget().getChildAt(4);
        rl1.setGravity(Gravity.CENTER_VERTICAL);
        TextView tv5=(TextView) rl1.getChildAt(1);
        tv5.setLayoutParams(tv);
        tv5.setTextAppearance(this, android.R.style.TextAppearance_Medium);
        tv5.setPadding(10, 0, 10, 0);
        tv5.setGravity(Gravity.CENTER);*/


    };
}
