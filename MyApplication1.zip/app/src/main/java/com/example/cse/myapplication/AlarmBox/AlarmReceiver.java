package com.example.cse.myapplication.AlarmBox;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.widget.Toast;

import com.example.cse.myapplication.R;

import java.util.Calendar;

public class AlarmReceiver extends BroadcastReceiver {
    public AlarmReceiver() {

    }

    @Override
    public void onReceive(Context context, Intent intent) {

        Bundle extra = intent.getExtras();
        if (extra != null)
        {
            boolean isOneTime = extra.getBoolean("one_time");
            if (isOneTime)
            {
                //AlarmDataManager.getInstance().setAlarmEnable(context, false);
                // 알람 울리기. 일회용이니까 지우는..그런게..있어야할거 같은데...

                Toast.makeText(context, extra.getString("tag")+"(약) 먹을 시간입니다~!", Toast.LENGTH_SHORT).show();
                NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                Resources res = context.getResources();

                NotificationCompat.Builder builder = new NotificationCompat.Builder(context)
                        .setContentTitle("복약 알람")
                        .setContentText(extra.getString("tag")+"(약) 복용 시간입니다.")
                        .setTicker(extra.getString("tag")+"(약) 복용 여부를 확인해주세요.")
                        .setSmallIcon(R.drawable.launcher)
                        .setLargeIcon(BitmapFactory.decodeResource(res, R.drawable.launcher))
                        .setAutoCancel(true)
                        .setWhen(System.currentTimeMillis())
                        .setDefaults( Notification.DEFAULT_SOUND|Notification.DEFAULT_VIBRATE|Notification.DEFAULT_LIGHTS);

                Notification  n = builder.build();
                nm.notify(1234, n); //노티피케이션 번호. 한 번에 하나씩만 확인할 수 있다. ;ㅅ;
            }
            else
            {
                boolean[] week = extra.getBooleanArray("day_of_week");

                Calendar cal = Calendar.getInstance();

                if (!week[cal.get(Calendar.DAY_OF_WEEK)])
                    return;

                // 알람 울리기.

                Toast.makeText(context,extra.getString("tag")+"(약) 먹을 시간입니다~!", Toast.LENGTH_SHORT).show();

                NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                Resources res = context.getResources();

                NotificationCompat.Builder builder = new NotificationCompat.Builder(context)
                        .setContentTitle("복약 알람")
                        .setContentText(extra.getString("tag")+"(약) 복용 시간입니다.")
                        .setTicker(extra.getString("tag")+"(약) 복용 여부를 확인해주세요.")
                        .setSmallIcon(R.drawable.launcher)
                        .setLargeIcon(BitmapFactory.decodeResource(res, R.drawable.launcher))
                        .setAutoCancel(true)
                        .setWhen(System.currentTimeMillis())
                        .setDefaults( Notification.DEFAULT_SOUND|Notification.DEFAULT_VIBRATE|Notification.DEFAULT_LIGHTS);

                Notification  n = builder.build();
                nm.notify(123, n);
            }
        }
    }

}
